define([
	'./todo/store/TodoLocalStorage',
	'./todo/widgets/CSSToggleWidget',
	'./todo/widgets/Todo',
	'./todo/widgets/TodoEscape',
	'./todo/widgets/TodoFocus',
	'./todo/widgets/Todos'
], 1);
