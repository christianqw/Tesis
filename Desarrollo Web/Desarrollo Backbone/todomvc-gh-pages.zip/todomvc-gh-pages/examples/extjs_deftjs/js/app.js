Ext.syncRequire(['TodoDeftJS.Application']);
Ext.create('TodoDeftJS.Application');