/*global define */

// Author: Loïc Knuchel <loicknuchel@gmail.com>

define({
	ENTER_KEY: 13,
	localStorageItem: 'todos-knockout-require'
});
