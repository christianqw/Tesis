/* global enyo: false */
enyo.depends(
	'$lib'
);