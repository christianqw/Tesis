require "isolate"
require "isolate/rake" if defined?(Rake)

Isolate.now! :system => false
